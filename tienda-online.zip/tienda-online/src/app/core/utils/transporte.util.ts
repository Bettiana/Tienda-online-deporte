export function transporteSegunTotal(total: number): number {
  if (total > 100) return 0;
  if (total > 50) return 5;
  return 10;
}