import { Injectable, signal, computed } from '@angular/core';
import { Producto } from '../models/producto.model';

@Injectable({ providedIn: 'root' })
export class CarritoService {
  private carrito = signal<Producto[]>([]);

  getCarrito() {
    return this.carrito.asReadonly();
  }

  cantidadTotal = computed(() => this.carrito().length);

  agregarProducto(producto: Producto) {
    if (producto.stock > 0) {
      this.carrito.update(lista => [...lista, producto]);
    }
  }

  eliminarProducto(id: number) {
    this.carrito.update(lista => lista.filter(p => p.id !== id));
  }

  limpiarCarrito() {
    this.carrito.set([]);
  }

  calcularTotal() {
    return this.carrito().reduce((acc, p) => acc + p.precio, 0);
  }
}