import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { ProductosService } from '../../core/services/productos.service';
import { CarritoService } from '../../core/services/carrito.service';
import { NgFor } from '@angular/common';

@Component({
  selector: 'app-productos',
  standalone: true,
  imports: [NgFor],
  template: `
    <div *ngFor="let producto of productos()">
      <h3>{{ producto.nombre }}</h3>
      <p>{{ producto.descripcion }}</p>
      <p><strong>{{ producto.precio }} €</strong></p>
      <p *ngIf="producto.stock === 0" class="producto-agotado">Agotado</p>
      <p *ngIf="producto.stock === 1" class="producto-ultimo">¡Última unidad!</p>
      <button (click)="comprar(producto)" [disabled]="producto.stock === 0">Comprar</button>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProductosComponent {
  private productosService = inject(ProductosService);
  private carritoService = inject(CarritoService);

  productos = signal<any[]>([]);

  constructor() {
    this.productosService.getProductos().subscribe(data => this.productos.set(data));
  }

  comprar(producto: any) {
    this.carritoService.agregarProducto(producto);
  }
}