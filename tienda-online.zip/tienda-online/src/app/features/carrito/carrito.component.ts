import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CarritoService } from '../../core/services/carrito.service';
import { transporteSegunTotal } from '../../core/utils/transporte.util';
import { NgFor } from '@angular/common';

@Component({
  selector: 'app-carrito',
  standalone: true,
  imports: [NgFor],
  template: `
    <section>
      <h2>Carrito</h2>
      <ul>
        <li *ngFor="let producto of carritoService.getCarrito()()">
          {{ producto.nombre }} - {{ producto.precio }} €
          <button (click)="eliminar(producto.id)">Eliminar</button>
        </li>
      </ul>
      <p>Total: {{ carritoService.calcularTotal() }} €</p>
      <p>Gastos de envío: {{ calcularTransporte() }} €</p>
      <button (click)="finalizarCompra()">Finalizar compra</button>
    </section>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CarritoComponent {
  carritoService = inject(CarritoService);

  eliminar(id: number) {
    this.carritoService.eliminarProducto(id);
  }

  calcularTransporte() {
    const total = this.carritoService.calcularTotal();
    return transporteSegunTotal(total);
  }

  finalizarCompra() {
    alert('¡Gracias por tu compra!');
    this.carritoService.limpiarCarrito();
  }
}